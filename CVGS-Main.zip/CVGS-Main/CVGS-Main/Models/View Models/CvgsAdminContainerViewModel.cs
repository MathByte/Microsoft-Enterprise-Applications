﻿namespace CVGS_Main.Models.View_Models
{
    public class CvgsAdminContainerViewModel
    {
        public List<CvgsGame> Games { get; set; }

        public List<CvgsEvent> Events { get; set; }

        public List<CvgsReview> Reviews { get; set; }
    }
}
