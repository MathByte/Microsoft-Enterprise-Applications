﻿namespace CVGS_Main.Models.View_Models
{
    public class CvgsCartViewModel
    {
        public CvgsCart CvgsCart { get; set; }
        public List<CvgsLineItem> LineItems { get; set; }
    }
}
