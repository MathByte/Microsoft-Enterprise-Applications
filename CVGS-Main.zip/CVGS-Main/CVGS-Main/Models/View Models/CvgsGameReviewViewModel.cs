﻿namespace CVGS_Main.Models.View_Models
{
    public class CvgsGameReviewViewModel
    {
        public CvgsGame Game { get; set; }

        public List<CvgsReview> Reviews { get; set; }
    }
}
