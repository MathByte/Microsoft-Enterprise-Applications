﻿namespace CVGS_Main.Models.View_Models
{
	public class CvgsFriendInputModel
	{
		public string Username { get; set; }
	}
}
